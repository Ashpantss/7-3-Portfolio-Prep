package Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import ContactClasses.Contact;

class ContactTest {


    @Test
    void testContact() {
        Contact contact = new Contact("1234567891", "Sarah", "Will", "1234456651", "st main tedd");
        assertTrue(contact.getcontactId().equals("1234567891"));
        assertTrue(contact.getfirstName().equals("Sarah"));
        assertTrue(contact.getfirstName().equals("will"));
        assertTrue(contact.getphoneNum().equals("1234456651"));
        assertTrue(contact.getAddress().equals("st main tedd"));
    }
    @Test
    void  TestContactTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("111234567891", "Sarah", "WIll", "123114456651", "st main tedd");
        }); }
    @Test
	void testContactClassFirstNameToLong() {
		// testing for IllegalArgumentException
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456789", "Kayla aaaaaa", "Wilson","555-1234", "123 NH St.");
		 });      }
	
	@Test
	void testContactClassLastNameToLong() {
		// testing for IllegalArgumentException
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456789", "sarah", "Wilson nnn nnn","555-1234", "123 NH St.");
		 });      }
	
	@Test
	void testContactClassPhoneNumberToLong() {
		// testing for IllegalArgumentException
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456789", "sarah", "Will", "1234566511111111111", "st ted str.");
		 });      }
	
	@Test
	void testContactClassAddressToLong() {
		// testing for IllegalArgumentException
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456789", "sarah", "Will","123456651", "st ted str 12345678910 12345678910 NH St.");
		 });      }

        @Test
        void  TestContactisNull() {
            Assertions.assertThrows(IllegalArgumentException.class, () -> {
                new Contact("1234567891", "Sarah", "Will", "1234456651", "st main tedd");
            }); }	
    	@Test
    	void testContactClassFirstNameIsNull() {
    		// testing for IllegalArgumentException
    		Assertions.assertThrows(IllegalArgumentException.class, () -> {
    			new Contact("123456789", null, "Wilson","555-1234", "123 NH St.");
    		 });      }
    	
    	@Test
    	void testContactClassLastNameIsNull() {
    		// testing for IllegalArgumentException
    		Assertions.assertThrows(IllegalArgumentException.class, () -> {
    			new Contact("123456789", "Kayla", null,"555-1234", "123 NH St.");
    		 });      }
    	
    	@Test
    	void testContactClassPhoneNumberIsNull() {
    		// testing for IllegalArgumentException
    		Assertions.assertThrows(IllegalArgumentException.class, () -> {
    			new Contact("123456789", "Kayla", "Wilson nnn nnn",null, "123 NH St.");
    		 });      }
    	
    	@Test
    	void testContactClassAddressIsNull() {
    		// testing for IllegalArgumentException
    		Assertions.assertThrows(IllegalArgumentException.class, () -> {
    			new Contact("123456789", "Kayla", "Wilson","555-1234 - 1234", null);
    		 });      }
    	
}


