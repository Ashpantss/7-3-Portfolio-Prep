package ContactClasses;
import java.util.ArrayList;
public class ContactService {
    ArrayList<Contact> list = new ArrayList<Contact>();

    public boolean addContact(Contact contact) {
        boolean isAdded = false;
        // empty list
        if (list.size() == 0) {
            list.add(contact);
            isAdded = true;
        } else {
            for (Contact c : list) {
                if (contact.getcontactId().equalsIgnoreCase(c.getcontactId())) {
                    return isAdded;
                }
            }
            list.add(contact);
            isAdded = true;
        }
        return isAdded;
    }
    public boolean remove(String contactId) {
        for (Contact c : list) {
            if (c.getcontactId().equalsIgnoreCase(c.getcontactId())) {
                Contact.remove(c);
                System.out.println("Contact removed Successfully!");
                return true;
            }
        }
        System.out.println("Contact not present");
        return false;
    }

    /*
    * this method updates the contact of the ID, if found updates it
    *  passes empty string if certain id attributes stay same
    */
    public boolean update(String ID, String firstName, String lastName, 
 		   String phoneNumber, String Address) {
        for (Contact c : list) {
            if (c.getcontactId().equalsIgnoreCase(c.getcontactId())) {
                if (!firstName.equals(""))
                    c.setfirstname(firstName);
                if (!lastName.equals(""))
                    c.setfirstname(lastName);
                if (!Address.equals(""))
                    c.setAddress(phoneNumber);
                if (!Address.equals(""))
                    c.setAddress(Address);
                System.out.println("Contact updated Successfully!");
                return true;
            }
        }
        System.out.println("Contact not present");
        return false;
    }

    }


