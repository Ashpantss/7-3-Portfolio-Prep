package ContactClasses;
public class Contact {
    private String contactId;
    private String firstName;
    private String lastName;
    private String phoneNum;
    private String Address;

    public Contact(String contactId, String firstName, String lastName, String phoneNum,
                          String Address) {
    	// invalid ID 
    	if (contactId == null || contactId.length() > 10) {
    	throw new IllegalArgumentException("Invalid Contact ID");
    }
    	// invalid first name 
        if (firstName == null || firstName.length() > 10) {
        throw new IllegalArgumentException("Invalid First Name");
    }
        //of ivalid last name
        if(lastName == null || lastName.length() > 10) {
        throw new IllegalArgumentException("Invalid Last Name");
    }
        // if invalid phone number
        if(phoneNum == null || phoneNum.length() > 10) {
        throw new IllegalArgumentException("Invalid phone number");
	}
        //setting Address
		if(Address == null || Address.length() > 30) {
		throw new IllegalArgumentException("Invalid Address");
		}
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNum = phoneNum;
        this.Address = Address;
    }
    
    //setters and getters  
    public String getcontactId() {
        return contactId;
    }
    public void setcontactId(String contactId) {
    	this.contactId = contactId;
    }
    public String getfirstName() {
        return firstName;
    }
    public void setfirstname(String firstName) {
        this.firstName = firstName;
    }
    public String getlastName(){
        return lastName;
    }
    public void setlastname(String lastName) {
        this.lastName = lastName;
    }
    public String getphoneNum(){
        return phoneNum;
    }
    public void setphoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }
    public String getAddress(){
        return Address;
    }
    public void setAddress(String Address) {
        this.Address = Address;
    }

	public static void remove(Contact c) {
		// TODO Auto-generated method stub
		
	}
}

