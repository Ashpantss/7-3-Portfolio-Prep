package TaskProjectMilestone;

//Task Service Requirements

import java.util.ArrayList;

public class TaskService {
   // this contains a list of tasks 
   private ArrayList<Task> tasks;

   //the default constructor
   public TaskService() {
       tasks = new ArrayList<>();
   }

   //  method adds  tasks to array list if its not already there
   public boolean add(Task task) {
       boolean alreadyPresent = false;
       for (Task c : tasks) {
           if (c.equals(task)) {
               alreadyPresent = true;
           }
       }
      // if task is present already //
       if (!alreadyPresent) {
           tasks.add(task);
           System.out.println("Task Added!");
           return true;
       } else {
           System.out.println("Task already there");
           return false;
       }
   }

   // removes a task with given is already there 
   public boolean remove(String ID) {
       for (Task c : tasks) {
           if (c.getID().equals(ID)) {
               tasks.remove(c);
               System.out.println("Task removed Successfully!");
           }
       }
       System.out.println("Task is not present");
       return false;
   }

   
   public boolean update(String ID, String name, String description) {
       for (Task c : tasks) {
           if (c.getID().equals(ID)) {
               if (!name.equals(""))
                   c.setname(name);
               if (!description.equals(""))
                   c.setdescription(description);

               System.out.println("Task updated.");
               return true;
           }
       }
       System.out.println("Task not present");
       return false;
   }

}