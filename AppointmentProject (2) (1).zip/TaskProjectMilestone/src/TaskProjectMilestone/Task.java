package TaskProjectMilestone;

//Ashlee Wood

//Variables 

public class Task {

	private String ID;
	private String name;
	private String description;

// Constructor with requirements

	public Task(String ID, String name, String description) {
		if(ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(name == null || name.length()>20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		if(description == null || description.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		// The parent class constructor call

				
		this.ID = ID;
		this.name = name;
		this.description = description;


	}
	
// Accessors and Mutators
// Getters and Setters

// Getter for ID
	public String getID() {
		return ID;
	}

// Setter for ID
	public void setID(String ID) {
		this.ID = ID;
	}
	
// Getter for name
	public String getname() {
		return name;
	}

// Setter for name
	public void setname(String name) {
		this.name = name;
	}

// Getter for description
	public String getdescription() {
		return description;
	}

// Setter for description
	public void setdescription(String description){
		this.description = description;
	}


}