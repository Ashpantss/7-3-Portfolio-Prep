package Test;

import static org.junit.Assert.*;
import org.junit.Test;
import TaskProjectMilestone.Task;
import TaskProjectMilestone.TaskService;

public class TaskServiceTest {

	// testing the add method to Pass
   @Test
   public void testMethodAddPass() {
      TaskService cs = new TaskService();
      Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
      Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
      Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c2));
       assertEquals(true, cs.add(c3));
   }

   /* testing the add method to Fail */
   @Test
   public void testMethodAddFail() {
      TaskService cs = new TaskService();
      Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
      Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
      Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c1));
       // Record does exist - can not be added
       assertEquals(false, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
   }

   /* testing the delete method to Pass*/
   @Test
   public void testMethodDeletePass() {
      TaskService cs = new TaskService();
      Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
      Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
      Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c2));
       assertEquals(true, cs.add(c3));
       // Records 1 and 2 exist so they can be deleted
       assertEquals(true, cs.remove("Task 1"));
       assertEquals(true, cs.remove("Task 2"));
   }

   /* testing the delete method to Fail*/
   @Test
   public void testMethodDeleteFail() {
	   TaskService cs = new TaskService();
	   Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
	      Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
	      Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       //Record 3 does not exist can not be deleted
       assertEquals(false, cs.remove("Task 4"));
       assertEquals(true, cs.remove("Task 2"));
   }

   /* testing the update method to Pass */
   @Test
   public void testUpdatePass() {
	   TaskService cs = new TaskService();
	   Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
	      Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
	      Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       // Records exist they can be updated
       assertEquals(true, cs.update("Task 3", "Sarah", "Method Task Implementater"));
       assertEquals(true, cs.update("Task 2", "Henry", "Second Task Implementater"));
   }

// update if failed 
   @Test
   public void testUpdateFail() {
	   TaskService cs = new TaskService();
	   Task c1 = new Task("Task 1", "Sarah", "Method Task Implementater");
	   Task c2 = new Task("Task 2", "Henry", "Second Task IMplementater");
	   Task c3 = new Task("Task 3", "Ginny", "Third Task Implementationer");
       assertEquals(true, cs.add(c1));
       assertEquals(true, cs.add(c3));
       assertEquals(true, cs.add(c2));
       // Record 4 does not exist no update so false
       assertEquals(false, cs.update("Task 4", "Cora", "nfbaojf'bda"));
       assertEquals(true, cs.update("Task 2", "Peace", "jbv svljd "));
   }

}