package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import TaskProjectMilestone.Task;



class TaskTest{
	
	@Test
	void testTask() {
		
	Task Task = new Task ("123", "Pammy","Teacher");
	
	// validating assertions are true for values assigned originally
	
	assertTrue(Task.getID().equals("123"));
	assertTrue(Task.getname().equals("Pammy"));
	assertTrue(Task.getdescription().equals("Teacher"));
	}

	//If too long 
	
		@Test
		void testTaskClassIdToLong() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("1234567891011", "Pammy", "Teacher");
			 });      }
		
		@Test
		void testTaskClassNameToLong() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("123456789", "PAMMYPammyPammyPammy", "SNHU Professor");
			 });      }
		
		@Test
		void testTaskClassDescriptionToLong() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("123456789", "PAMMYPammyPammyPammy","This description is over fifty characters long. It should be shorter.");
			 });      }
		
		
		
		
		// Tests for fields being null
		@Test
		void testTaskClassIdIsNull() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task(null, "Pammy", "Teacher");
			 });      }
		
		@Test
		void testTaskClassNameIsNull() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task ("123456789", null, "Teacher");
			 });      }
		
		@Test
		void testTaskClassDescriptionIsNull() {
			// testing for IllegalArgumentException
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Task("123456789", "Pammy", null);
			 });      }
		


	}