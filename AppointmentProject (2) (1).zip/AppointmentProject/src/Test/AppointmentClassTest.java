package Test;
import org.junit.Test;

import Appoint.AppointmentClass;

import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentClassTest {

    @Test
    public void testCreateAppointment() {
        AppointmentClass appointment = new AppointmentClass("A00001", new Date(), "Appointment Description");
        assertNotNull(appointment);
    }

    @Test
    public void testAppointmentID() {
        AppointmentClass appointment = new AppointmentClass("A00001", new Date(), "Appointment Description");
        assertEquals("A00001", appointment.getappointmentId());
    }

    @Test
    public void testAppointmentDate() {
        Date appointmentDate = new Date();
        AppointmentClass appointment = new AppointmentClass("A00001", appointmentDate, "Appointment Description");
        assertEquals(appointmentDate, appointment.getappointmentDate());
    }

    @SuppressWarnings("unused")
	@Test(expected = IllegalArgumentException.class)
    public void testAppointmentDateInThePast() {
        Date appointmentDate = new Date(System.currentTimeMillis() - 1000 * 60 * 60 * 24);
        new AppointmentClass("A00001", appointmentDate, "Appointment Description");
    }

    @Test
    public void testAppointmentDescription() {
        assertEquals("Appointment Description", AppointmentClass.getappointmentDesc());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentIDTooLong() {
        new AppointmentClass("A0000000001", new Date(), "Appointment Description");
    }

    @Test(expected = NullPointerException.class)
    public void testAppointmentIDNull() {
        new AppointmentClass(null, new Date(), "Appointment Description");
    }

    @Test(expected = NullPointerException.class)
    public void testAppointmentDateNull() {
    }

    @Test(expected = NullPointerException.class)
    public void testAppointmentDescriptionNull() {
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAppointmentDescriptionTooLong() {
    }
}
