package Test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import Appoint.AppointmentClass;
import Appoint.AppointmentService;
public class AppointmentServiceTest {
    
    private AppointmentService appointmentService;
    
    @Before
    public void setUp() {
        appointmentService = new AppointmentService();
    }
    
    @Test
    public void testAddAppointment() {
        AppointmentClass appointment = new AppointmentClass("A123456789", new Date(), "Test Appointment");
        assertTrue(appointmentService.add(appointment));
    }
    
    @Test
    public void testAddDuplicateAppointment() {
        AppointmentClass appointment1 = new AppointmentClass("A123456789", new Date(), "Test Appointment 1");
        AppointmentClass appointment2 = new AppointmentClass("A123456789", new Date(), "Test Appointment 2");
        appointmentService.add(appointment1);
        assertFalse(appointmentService.add(appointment2));
    }
    
    @Test
    public void testDeleteAppointment() {
        AppointmentClass appointment = new AppointmentClass("A123456789", new Date(), "Test Appointment");
        appointmentService.add(appointment);
        assertTrue(appointmentService.remove("A123456789"));
    }
    
    @Test
    public void testDeleteNonExistentAppointment() {
        assertFalse(appointmentService.remove("B123456789"));
    }
    
    @Test
    public void testGetAppointment() {
        AppointmentClass appointment = new AppointmentClass("A123456789", new Date(), "Test Appointment");
        appointmentService.add(appointment);
        assertEquals(appointment, appointmentService.add("A123456789"));
    }
    
    @Test
    public void testGetNonExistentAppointment() {
        assertNull(appointmentService.add("B123456789"));
    }
    
    @Test
    public void testGetAppointments() {
        AppointmentClass appointment1 = new AppointmentClass("A123456789", new Date(), "Test Appointment 1");
        AppointmentClass appointment2 = new AppointmentClass("B123456789", new Date(), "Test Appointment 2");
        appointmentService.add(appointment1);
        appointmentService.add(appointment2);
        assertEquals(2, appointmentService.getAppointments().size());
    }
    
}