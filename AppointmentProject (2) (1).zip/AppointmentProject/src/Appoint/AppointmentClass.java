package Appoint;
import java.util.Date;
public class AppointmentClass {
	

	private String appointmentId;
	private Date appointmentDate;
	private static String appointmentDesc;


	public AppointmentClass(String appointmentId, Date appointmentDate, String appointmentDesc) {
		if(appointmentId == null || appointmentId.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		this.appointmentId = appointmentId;
		
		if(appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date.");
		}
		this.appointmentDate = appointmentDate;
		
		if(appointmentDesc == null || appointmentDesc.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		AppointmentClass.appointmentDesc = appointmentDesc;
	
	}
	
//Getters 
	//setters 
	// Setter for Id
    public void setAppointdId(String AppointmentId) {

    if(AppointmentId == null || AppointmentId.length()>10) {
            throw new IllegalArgumentException("Invalid Name");
        }
      this.appointmentId = AppointmentId;
    }

//Getter for ID
	public String getappointmentId() {
		return appointmentId;
	}
	
//Getter for name
	public Date getappointmentDate() {
		return appointmentDate;
	}

//Getter for description
	public static String getappointmentDesc() {
		return appointmentDesc;
	}


}