package Appoint;

import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private List<AppointmentClass> appointments;
    
    public AppointmentService() {
        appointments = new ArrayList<>();
    }
    public boolean add(AppointmentClass appointment) {
        /* Is task present */
        boolean alreadyPresent = false;
        for (AppointmentClass c : appointments) {
            if (c.equals(appointment)) {
                alreadyPresent = true;
            }
        }
        /* if not present then we add Appointment, and return true else false*/
        if (!alreadyPresent) {
     	   appointments.add(appointment);
            System.out.println("Appointment Added Successfully!");
            return true;
        } else {
            System.out.println("Appointment already present");
            return false;
        }
    }

    /* method removes a Appointment with given ID if present */
    public boolean remove(String ID) {
        for (AppointmentClass c : appointments) {
            if (c.getappointmentId().equals(ID)) {
         	   appointments.remove(c);
                System.out.println("Appointment removed Successfully!");
                return true;
            }
        }
        System.out.println("Appointment not present");
        return false;
    
	}
    public List<AppointmentClass> getAppointments() {
        return appointments;
    }
	public Object add(String string) {
		// TODO Auto-generated method stub
		return null;
	}
}